'use client';

import Link from 'next/link';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth/AuthProvider';
import styles from './landing.module.css';

const APP_NAME =
  process.env.NEXT_PUBLIC_APP_NAME ?? 'Market Trading Room Simulator';

export default function LandingPage() {
  const { status } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (status === 'authenticated') {
      router.replace('/dashboard');
    }
  }, [status, router]);

  if (status !== 'unauthenticated') {
    return (
      <div className="page-shell" role="status" aria-live="polite">
        <p>{status === 'authenticated' ? 'Opening your dashboard…' : 'Loading…'}</p>
      </div>
    );
  }

  return (
    <div className={styles.hero}>
      <header className={styles.top}>
        <div className="brand-mark">
          <span className="brand-glyph" aria-hidden />
          <span>MTRS</span>
        </div>
        <div className={styles.topActions}>
          <Link href="/login" className="btn btn-ghost">
            Sign in
          </Link>
          <Link href="/register" className="btn btn-primary">
            Create account
          </Link>
        </div>
      </header>

      <section className={styles.stage} aria-labelledby="hero-brand">
        <p className={styles.kicker}>Identity · Sessions · Administration</p>
        <h1 id="hero-brand" className={styles.brand}>
          {APP_NAME}
        </h1>
        <p className={styles.lead}>
          Secure entry to the trading room simulator — verified accounts,
          multi-factor sign-in, and operator controls without exposing market
          fiction as fact.
        </p>
        <div className={styles.cta}>
          <Link href="/register" className="btn btn-primary">
            Get started
          </Link>
          <Link href="/login" className="btn btn-secondary">
            Sign in
          </Link>
        </div>
      </section>
    </div>
  );
}
