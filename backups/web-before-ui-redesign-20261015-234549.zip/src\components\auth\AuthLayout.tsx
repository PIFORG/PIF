import Link from 'next/link';
import type { ReactNode } from 'react';
import styles from './AuthLayout.module.css';

const APP_NAME =
  process.env.NEXT_PUBLIC_APP_NAME ?? 'Market Trading Room Simulator';

interface AuthLayoutProps {
  title: string;
  lead?: string;
  children?: ReactNode;
  footer?: ReactNode;
}

export function AuthLayout({ title, lead, children, footer }: AuthLayoutProps) {
  return (
    <div className={styles.shell}>
      <aside className={styles.brandPane} aria-label="Product introduction">
        <div className={styles.brandTop}>
          <Link href="/" className="brand-mark">
            <span className="brand-glyph" aria-hidden />
            <span>MTRS</span>
          </Link>
          <h1 className={styles.productName}>{APP_NAME}</h1>
          <p className={styles.tagline}>
            A professional identity workspace for simulated market trading
            rooms — secure access, session control, and operator tooling.
          </p>
        </div>
        <p className={styles.brandFoot}>English-first · Cookie refresh · MFA ready</p>
      </aside>
      <main className={styles.formPane}>
        <div className={styles.formInner}>
          <h2 className={styles.formTitle}>{title}</h2>
          {lead ? <p className={styles.formLead}>{lead}</p> : null}
          {children}
          {footer ? <div className={styles.footerLinks}>{footer}</div> : null}
        </div>
      </main>
    </div>
  );
}
