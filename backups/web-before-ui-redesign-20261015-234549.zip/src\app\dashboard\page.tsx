'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { AccountStatusBadge } from '@/components/layout/AccountStatusBadge';
import { AppShell } from '@/components/layout/AppShell';
import { describeApiError } from '@/lib/api/errors';
import type { DashboardContext, DashboardModule } from '@/lib/api/types';
import * as usersApi from '@/lib/api/users';
import { useAuth } from '@/lib/auth/AuthProvider';

function greetingForHour(date = new Date()): string {
  const hour = date.getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

const MODULE_LINKS: Record<string, string> = { admin: '/admin' };

function moduleState(mod: DashboardModule): { label: string; className: string } {
  if (!mod.available) return { label: 'Not available yet', className: 'badge badge-muted' };
  if (!mod.permitted) return { label: 'Not permitted for your account', className: 'badge badge-muted' };
  return { label: 'Available', className: 'badge badge-active' };
}

function DashboardContent() {
  const { user } = useAuth();
  const [context, setContext] = useState<DashboardContext | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    usersApi
      .fetchDashboardContext()
      .then((ctx) => !cancelled && setContext(ctx))
      .catch((err) => !cancelled && setError(describeApiError(err, 'Unable to load your workspace.')));
    return () => {
      cancelled = true;
    };
  }, [user?.role, user?.mfaEnabled]);

  if (!user) return null;

  return (
    <AppShell>
      <div className="page-shell">
        <header style={{ marginBottom: '1.75rem' }}>
          <p style={{ marginBottom: '0.35rem', color: 'var(--color-text-subtle)' }}>
            {greetingForHour()}
          </p>
          <h1 style={{ marginBottom: '0.5rem' }}>
            {user.firstName} {user.lastName}
          </h1>
          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <AccountStatusBadge status={user.status} />
            <span className="badge badge-muted">{user.role === 'ADMIN' ? 'Administrator' : 'Investor'}</span>
            <span className="badge badge-muted">Experience: {user.experienceLevel.toLowerCase()}</span>
            {!user.emailVerified ? <span className="badge badge-pending">Email unverified</span> : null}
          </div>
          {context?.experienceLevelNotice ? (
            <p className="field-hint" style={{ marginTop: '0.75rem' }}>
              {context.experienceLevelNotice}
            </p>
          ) : null}
        </header>

        {!user.emailVerified ? (
          <div className="form-error-banner" style={{ marginBottom: '1.5rem' }}>
            Verify your email to unlock full account capabilities.{' '}
            <Link href="/resend-verification">Resend verification</Link>
          </div>
        ) : null}

        {context?.requiredActions.includes('ENROLL_MFA_FOR_ADMIN') ? (
          <div className="form-error-banner" role="status" style={{ marginBottom: '1.5rem' }}>
            Administrator tools are locked until you turn on two-step verification.{' '}
            <Link href="/settings/security">Set it up now</Link>
          </div>
        ) : null}

        {error ? (
          <div className="form-error-banner" role="alert" style={{ marginBottom: '1.5rem' }}>
            {error}
          </div>
        ) : null}

        <section aria-labelledby="modules-heading">
          <h2 id="modules-heading">Workstation modules</h2>
          <p>Account and security tools are live. Market modules will appear here when they are released.</p>
          <div className="module-grid" style={{ marginTop: '1rem' }}>
            <article className="module-tile">
              <h3>Identity &amp; security</h3>
              <p>Profile, two-step verification, sessions and account controls.</p>
              <Link href="/settings/profile" className="btn btn-secondary">
                Open
              </Link>
            </article>
            {context
              ? context.modules
                  .filter((mod) => mod.id !== 'admin' || user.role === 'ADMIN')
                  .map((mod) => {
                    const state = moduleState(mod);
                    const href = MODULE_LINKS[mod.id];
                    return (
                      <article key={mod.id} className="module-tile">
                        <h3>{mod.label}</h3>
                        {mod.permitted && mod.available && href ? (
                          <Link href={href} className="btn btn-secondary">
                            Open
                          </Link>
                        ) : (
                          <span className={state.className}>{state.label}</span>
                        )}
                      </article>
                    );
                  })
              : !error
                ? (
                    <p role="status">Loading modules…</p>
                  )
                : null}
          </div>
        </section>
      </div>
    </AppShell>
  );
}

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  );
}
