'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { ReactNode } from 'react';
import { PermissionGate } from '@/components/auth/PermissionGate';
import { ProfileDropdown } from '@/components/layout/ProfileDropdown';

const APP_NAME =
  process.env.NEXT_PUBLIC_APP_NAME ?? 'Market Trading Room Simulator';

interface AppShellProps {
  children: ReactNode;
}

function NavItem({
  href,
  label,
  current,
  disabled,
}: {
  href: string;
  label: string;
  current?: boolean;
  disabled?: boolean;
}) {
  if (disabled) {
    return (
      <span className="nav-link is-disabled" aria-disabled="true" title="Not available yet">
        {label}
        <span className="sr-only"> (not available yet)</span>
      </span>
    );
  }
  return (
    <Link
      href={href}
      className="nav-link"
      aria-current={current ? 'page' : undefined}
    >
      {label}
    </Link>
  );
}

export function AppShell({ children }: AppShellProps) {
  const pathname = usePathname();

  return (
    <>
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <header className="app-header">
        <Link href="/dashboard" className="brand-mark">
          <span className="brand-glyph" aria-hidden />
          <span className="brand-name">{APP_NAME}</span>
        </Link>
        <nav className="nav-links" aria-label="Primary">
          <NavItem
            href="/dashboard"
            label="Dashboard"
            current={pathname === '/dashboard'}
          />
          <NavItem href="#" label="Trading room" disabled />
          <NavItem href="#" label="Portfolio" disabled />
          <NavItem href="#" label="Training" disabled />
          <NavItem
            href="/settings/profile"
            label="Settings"
            current={pathname.startsWith('/settings')}
          />
          <PermissionGate roles={['ADMIN']}>
            <NavItem
              href="/admin"
              label="Admin"
              current={pathname.startsWith('/admin')}
            />
          </PermissionGate>
        </nav>
        <ProfileDropdown />
      </header>
      <main id="main-content">{children}</main>
    </>
  );
}
